# Todo List width Boostrap

This project was bootstrapped with Create React App

## Available Scripts

In the project directory, you can run:

### `npm install`
### `npm start`

## Features

부트스트랩 연동, 로컬스토리지 연동, Todo List
